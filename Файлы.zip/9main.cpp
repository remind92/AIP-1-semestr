#include <iostream>
#include <string>


int main()
{
    float surename,name,year,tipe,price;


    std::cout<<"surename"<<std::endl;
    std::cin>>surename;
    std::cout<<"name"<<std::endl;
    std::cin>>name;
    std::cout<<"year"<<std::endl;
    std::cin>>year;
    std::cout<<"tipe"<<std::endl;
    std::cin>>tipe;
    std::cout<<" price"<<std::endl;
    std::cin>>price;





    return 0;
}
