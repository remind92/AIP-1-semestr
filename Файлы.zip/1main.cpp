#include <iostream>
#include <cmath>


int main()
{
    int a, b, c, d;
    std::cin>>a>>b>>c;
    a = a*2;
    b = b-3;
    c = c*c;
    d = a+b+c;
    std::cout<<d;


    return 0;
}

