#include <iostream>
#include <cmath>


int main()
{
    int a, b, L, R, S;
    std::cout<<"L:";
    std::cin>>L;
    std::cout<<"R:";
    std::cin>>R;
    a = (M_PI)*R*L;
    b = (M_PI)*(R*R);
    S = a + b;
    std::cout<<S;

    return 0;
}
