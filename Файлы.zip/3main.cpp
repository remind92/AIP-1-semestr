#include <iostream>
#include <cmath>


int main()
{
    int a, b, c;
    std::cout<<"a";
    std::cin>>a;
    std::cout<<"b";
    std::cin>>b;
    c = ((a+(4*b))*(a-(3*b))+(a*a));
    std::cout<<c;



    return 0;
}
