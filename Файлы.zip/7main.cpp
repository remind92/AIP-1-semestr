#include <iostream>
#include <string>


int main()
{
    int name,proizv,price,sort,srok;


    std::cout<<"name"<<std::endl;
    std::cin>>name;
    std::cout<<"proizv"<<std::endl;
    std::cin>>proizv;
    std::cout<<"price"<<std::endl;
    std::cin>>price;
    std::cout<<"sort"<<std::endl;
    std::cin>>sort;
    std::cout<<"srok"<<std::endl;
    std::cin>>srok;





    return 0;
}
