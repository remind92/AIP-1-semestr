#include <iostream>
#include <cmath>


int main()
{
    float a, b, mtr, gek, ark;
    std::cin>>a>>b;
    mtr = a*b;
    gek = a*b/10000;
    ark = a*b/4047;
    std::cout<<mtr<<" "<<gek<<" "<<ark;



    return 0;
}
