#include <iostream>
#include <string>


int main()
{
    int name,kyrs,semestr,suremaneprepodav,ekzamen;


    std::cout<<"name"<<std::endl;
    std::cin>>name;
    std::cout<<"kyrs"<<std::endl;
    std::cin>>kyrs;
    std::cout<<"semestr"<<std::endl;
    std::cin>>semestr;
    std::cout<<"suremane prepodav"<<std::endl;
    std::cin>>suremaneprepodav;
    std::cout<<"ekzamen"<<std::endl;
    std::cin>>ekzamen;





    return 0;
}
