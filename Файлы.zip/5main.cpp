#include <iostream>
#include <cmath>


int main()
{
    int a, b, c;
    std::cin>>a>>b>>c;
    if (a > b,c){
        std::cout<<a;
    }

    else if (b > a,c){
        std::cout<<b;
    }
    else{
        std::cout<<c;
    }





    return 0;
}
